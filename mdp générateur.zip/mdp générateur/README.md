# G�n�rateur de mot de passe en python
